---
name: Modern Masala Dark
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1b1c1c'
  surface-container: '#1f2020'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353535'
  on-surface: '#e4e2e1'
  on-surface-variant: '#dac1b8'
  inverse-surface: '#e4e2e1'
  inverse-on-surface: '#303030'
  outline: '#a28c84'
  outline-variant: '#54433c'
  surface-tint: '#ffb596'
  primary: '#ffb596'
  on-primary: '#581e00'
  primary-container: '#a0522d'
  on-primary-container: '#ffe1d6'
  inverse-primary: '#944925'
  secondary: '#f0c12c'
  on-secondary: '#3d2e00'
  secondary-container: '#d2a501'
  on-secondary-container: '#503d00'
  tertiary: '#cac99f'
  on-tertiary: '#323214'
  tertiary-container: '#aead85'
  on-tertiary-container: '#414122'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdbcd'
  primary-fixed-dim: '#ffb596'
  on-primary-fixed: '#360f00'
  on-primary-fixed-variant: '#76320f'
  secondary-fixed: '#ffdf90'
  secondary-fixed-dim: '#f0c12c'
  on-secondary-fixed: '#241a00'
  on-secondary-fixed-variant: '#584400'
  tertiary-fixed: '#e6e5b9'
  tertiary-fixed-dim: '#cac99f'
  on-tertiary-fixed: '#1d1d03'
  on-tertiary-fixed-variant: '#484828'
  background: '#131313'
  on-background: '#e4e2e1'
  surface-variant: '#353535'
typography:
  headline-xl:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-md:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  body-lg:
    fontFamily: Open Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Open Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Open Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 14px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  container-max: 1200px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 40px
  stack-xs: 8px
  stack-md: 24px
  stack-lg: 48px
---

## Brand & Style

The brand personality is a sophisticated fusion of heritage and contemporary hospitality, reimagined for an intimate evening atmosphere. It balances the vibrant, sensory richness of Indian street food culture with the streamlined efficiency of a modern urban cafe. The target audience includes discerning food enthusiasts and urban professionals seeking an elevated yet warm and moody "third space."

The visual style follows a **Modern Minimalist** approach with **Tactile** accents. It leverages dark surfaces to create a sense of premium intimacy, while using deep earthy tones and subtle textile-inspired patterns to provide a grounded, organic feel. The interface should feel curated and intentional, using light and shadow to create a sense of warmth against the dark background.

## Colors

The palette is rooted in the "Modern Masala" theme, utilizing spice-inspired hues to evoke warmth and flavor in a dark mode setting.

- **Primary (Deep Terracotta):** Used for key brand elements, primary actions, and structural accents. It provides a grounded, clay-like warmth that glows against dark surfaces.
- **Secondary (Warm Saffron):** Reserved for highlights, notifications, and interactive hover states. It adds a vibrant energy to the dark interface.
- **Tertiary (Creamy Chai):** In this dark theme, Chai is used as an accent color for containers and highlighted text, providing a soft, organic contrast to the deep background.
- **Neutral (Charcoal Grey):** The primary background and surface color. It ensures legibility and a professional, sophisticated finish.

Background patterns should be implemented in a very low-opacity Terracotta or Saffron (1-2%) over the Charcoal surfaces to mimic the subtle texture of block-printed textiles in low light.

## Typography

This design system employs a serif-sans pairing to bridge the gap between traditional elegance and modern utility.

**Playfair Display** is used for headlines to provide a high-contrast, editorial feel that suggests quality and heritage. **Open Sans** handles the bulk of the reading experience, chosen for its exceptional legibility. **Plus Jakarta Sans** is introduced for labels and small UI elements to provide a contemporary, geometric touch to functional components.

Apply tight letter spacing to large headlines for a more modern, "locked-in" look. Use generous line height for body text to maintain an airy, premium feel and ensure high legibility against the dark background.

## Layout & Spacing

The layout utilizes a **Fixed Grid** system for desktop, centering the content within a 1200px container to maintain focus. A 12-column grid provides flexibility for menu layouts and promotional sections.

- **Desktop:** 12 columns, 24px gutters, 40px outer margins.
- **Tablet:** 8 columns, 16px gutters, 24px outer margins.
- **Mobile:** 4 columns, 16px gutters, 16px outer margins.

Spacing follows an 8px base rhythm to ensure consistent vertical flow. Generous section padding (using `stack-lg`) is encouraged to maintain the minimalist aesthetic and prevent the dark interface from feeling crowded.

## Elevation & Depth

Hierarchy is established using **Luminance Layering** and **Tonal Accents**. 

The Charcoal Grey background acts as the base canvas. Elevated elements like cards and navigation bars use slightly lighter charcoal shades rather than heavy shadows. To maintain warmth, elevated surfaces can feature a very soft, diffused outer glow tinted with the Primary Terracotta color (#A0522D at 12% opacity). 

Surfaces that require distinction but not high elevation use subtle borders (1px) in a slightly lighter shade of the background color. Depth should feel atmospheric and natural, reminiscent of a dimly lit, high-end interior.

## Shapes

The design system uses a **Rounded** shape language to evoke friendliness and comfort. 

- **Small Components (Buttons, Inputs):** 0.5rem (8px) corner radius.
- **Medium Components (Cards, Modals):** 1rem (16px) corner radius.
- **Large Components (Feature Banners):** 1.5rem (24px) corner radius.

Geometric textile patterns should be used as masks or background elements, often clipped within these rounded containers to maintain a consistent silhouette.

## Components

- **Buttons:** Primary buttons use a solid Deep Terracotta background with white text. Secondary buttons use a Creamy Chai outline for high contrast. Ghost buttons use Saffron text for subtle calls to action.
- **Cards:** Used for menu items and blog posts. Feature a slightly lighter Charcoal surface, a soft terracotta-tinted glow, and 16px padding.
- **Input Fields:** Minimalist style with a 1px light-grey bottom border that transitions to a full 1px Deep Terracotta frame on focus.
- **Chips/Tags:** Used for dietary labels (e.g., Vegan, Spicy). These use high-saturation backgrounds (Saffron or Terracotta) with small, clear typography.
- **Lists:** Menu lists should use generous vertical spacing and thin, low-opacity terracotta dividers to maintain clarity without visual noise.
- **Featured Accents:** Use circular "stamp" style elements for promotions or daily specials, referencing traditional Indian wax seals, enhanced with a subtle glow for the dark theme.